
// a = 7

// console.log(a*1)
// console.log(a*2)
// console.log(a*3)
// console.log(a*4)
// console.log(a*5)
// console.log(a*6)
// console.log(a*7)
// console.log(a*8)
// console.log(a*8)
// console.log(a*10)


// fname = 'Atiq'
// lname = "ansari"
// mName = `husain`
// console.log(fname)
// console.log(mName)
// console.log(lname)

// console.log("first")

isloggedIn = true
isloggedIn = false

// mNumber = BigInt(9876543456789876908765678909876545678765678976567897657897657897678976789767897656789767897657897678978908765)
// console.log(mNumber)

jsBatch = ['a','b','c','d']
console.log(jsBatch)
console.log(jsBatch[0])
console.log(jsBatch[1])
console.log(jsBatch[2])
console.log(jsBatch[3])
console.log(jsBatch[4])

htmlBatch = []
htmlBatch[1] = 'yadnesh'
htmlBatch[0] = 'Hrishikesh'
console.log(htmlBatch)


jsBatchObj = {
    fname : "Ria",
    lname : "gupta",
    11 : 11
}

console.log(jsBatchObj.fname)
console.log(jsBatchObj.lname)
console.log(jsBatchObj.age)
console.log(jsBatchObj[11])


fname = "krishna"
mNumber = 54345




jj = false
console.log(typeof jj, "sfhdbvh")
console.log(Array.isArray(jsBatchObj))