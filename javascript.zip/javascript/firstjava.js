// let carName="volvo"
// console.log(carName)

// let x=50
// console.log(x)

// a=5
// b=10
// console.log(a+b)

// let c=5;
// let d=10;
// let z=c+d
// alert(z)

// let firtName="john",
// lastName="Doe",
//  age=35
// console.log(firtName,lastName,age)

// alert(10*5)

// x=10
// y=5
// console.log(x+=y)

// var birthYear=2000;
// var futureYear=2024;
// console.log(birthYear-futureYear)

// let numberChildern=2,
//   parentName="yash",
//   geography="badlapur",
//   jobTitle="developer"
//   console.log(numberChildern,parentName,geography,jobTitle)


//   let currentAge=24,
//      maximumAge=50,
//     estimatedAmmount=2
//   console.log(estimatedAmmount*365)*(maximumAge-currentAge)
// hour=10
// if (hour <=18) {
//     greeting = "Good day";
//   } else {
//     greeting = "Good evening";
//   }
//   console.log(hour)
//  x=10
// y=5
// console.log(x+=y)

// loop
// for(count=1; count <=5; count++  ){
//   console.log("good morning")
// }
// number loop
// for(numberCount=0; numberCount<=20; numberCount++){
//   console.log(numberCount)
// }
// let sum=0;
// for(let i=1; i<=5; i++ ){
//   sum=sum+i
// }  console.log(sum)
// l

// while(i<=20){
//   console.log("hello")
//   i++
// }

// let i=9
// do{
//   console.log("hello")
//   i++;
// }
// while(i>=30)
//  let i=10
// do{
// console.log("hello bello ")
// i++;

// }while(i>=20);

// let string="cricket"

// let size=0;
// for (let i of string){
//     console.log("i",i);
//     size++;
// }
// console.log("string size",size)

// let thr="football"

// let size=0
// for(let i of thr){
//     console.log("i",i)
//     size++
// }console.log("thr size", size)

// let student= {
//     fullNAme:"atiq ansari",
//     rollNumber:40,
//     ccgp:8.1,
//     location:badlapur,
// };
// for(let key in student)
//     {
// console.log("key=",key ,"value=",student{key});
// }


// for(let num=0; num<=100; num++){
//     if(num%2===0)
//         console.log("num=",num)

// }

// let gameNumber=10;

// let userNAme=prompt("guess the right number");

// while(userNAme != gameNumber) {
//    let userNAme=prompt("guess the right number");

// }
// console.log("happy")
// console,log("congrats you entered right number")

// let object={
//     price:10,
//     pen:"ball pen",

// }
// let output=`the cost of pen ${object.price} is ${object.pen}`
// console.log(output)
// console.log("the cost of pen",object.price,object.pen)

// let fullName =prompt("enter full name without space")
// let userName= "@" + fullName+fullName.length;
// console.log(userName)




// problem solve 


// question 1
// console.log("Hello World")

// question 2
// let a=10,
// b=35549;
// console.log(a+b)

// question 3

// function calculateArea(length, width){
//     let area=length * width
//     // console.log( "area of rectange is",area )
// }
// calculateArea=(4 *10);
// console.log("area of rectange is",calculateArea);

// array 

// let city=["delhi","mumbai","goa",
//     "thane","badlapur"
// ]
// for( let i =0; i < city.length; ++i ){
//     console.log(city);
// }
// console.log("hellos")


// let country=[
//     'india','africa','america','newland','england','south america'
// ]
// for(let i=0;i<country.length;++i){
//     console.log(country)
// }

// for(let city of country){
//     console.log(city.toUpperCase );
// }

// let marks=[
//     85,97,44,37,76,60
// ];
// let sum=0;
// for(let val of marks){
//     sum + marks;
// }
// let avg=sum/marks.length
// console.log('total average of class= ${avg}')
// let item=10
// for(i=1; i<=item;i++)
//     console.log(i)

// let item=10
// for(i=1; i<=item;i++)
//     console.log(i*5)

// let fruit=[
//     "apple","banana","cerry","mango"
// ];
// for(
//     let i=0; i<fruit.length; i++
// ){
//     console.log(fruit[i])
// }

// let sum=0;
// for(let i=1; i <= 5; i++){
//     sum+=i;
//     console.log(sum)
// }
// let num=10
// for(let i=10; i>=1; i--){
//     console.log(i)
// }



